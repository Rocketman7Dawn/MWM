# Mindfulness with Mind
A soulful frontend for the MWM Chat and Email Agent.